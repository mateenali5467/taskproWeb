import React from 'react';
import {Chat, ProjectHead} from "../../../components";

const ProjectMessages = () => {
  return (
    <div>
      <ProjectHead/>
      <Chat/>
    </div>
  );
};

export default ProjectMessages;
